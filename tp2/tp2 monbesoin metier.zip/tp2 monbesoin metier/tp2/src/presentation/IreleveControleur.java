package presentation;

public interface IreleveControleur {

    void afficher_Mensualite(Long idreleve)
            throws Exception;
}
