package modele;

public class Professeur {
    long nom;
    String prenom;
    String email;
    String cin;
    int tel;
    String sexe;
}
