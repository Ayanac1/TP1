package modele;

public class Nom_Demandeur {
    long nom;
    String prenom;
    String email;
    String cin;
    int tel;
    String sexe;
}
