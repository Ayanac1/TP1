package dao.daoMySql;

import modele.Compte;
import modele.Nom_Demandeur;
import modele.Professeur;

import java.util.List;

public class ProfesseurDao {
    public Professeur findById (long id ){return null;}

    public List<Professeur> findAll(){return null;}
    public Professeur save (Professeur professeur){return null;}
    public Professeur update (Professeur professeur){return null;}
    public boolean delete (Professeur professeur){return false;}
    public boolean deleteById (long id){return false;}
}
