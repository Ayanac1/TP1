package dao;

public class FactoryId extends Factory {
    @Override
    public Idao getEtudiantDao() {
        return null;
    }

    @Override
    public Idao getProfesseurDao() {
        return null;
    }

    @Override
    public Idao getAdminDao() {
        return null;
    }

    @Override
    public Idao getCompteDao() {
        return null;
    }

    @Override
    public Idao getDepartementDao() {
        return null;
    }

    @Override
    public Idao getFiliereDao() {
        return null;
    }

    @Override
    public Idao getMatiereDao() {
        return null;
    }

    @Override
    public Idao getNoteDao() {
        return null;
    }

    @Override
    public Idao getSeanceDao() {
        return null;
    }

    @Override
    public Idao getSemestreDao() {
        return null;
    }
}
