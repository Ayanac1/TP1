package dao;

public class DAOConfigException extends Throwable {
    public DAOConfigException(String s) {
    }
}
